import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-white via-teal-50 to-cyan-50 py-24 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=1200')] bg-cover bg-center opacity-5"></div>
        <div className="relative max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl md:text-6xl font-bold mb-6 text-gray-900">
                Hi, I'm{" "}
                <span className="bg-gradient-to-r from-teal-500 to-cyan-500 bg-clip-text text-transparent">
                  Alessia
                </span>
              </h1>
              <p className="text-xl text-gray-600 mb-8">From New York to Tampa – discovering fun without limits</p>
              <Button
                asChild
                className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white border-0 shadow-lg"
              >
                <Link href="/explore">Explore My Discoveries</Link>
              </Button>
            </div>
            <div className="relative">
              <div className="relative w-full max-w-md mx-auto">
                <div className="absolute inset-0 bg-gradient-to-r from-teal-500/20 to-cyan-500/20 rounded-2xl blur-xl"></div>
                <Image
                  src="/placeholder.svg?height=500&width=400"
                  alt="Alessia Pedrazzoli"
                  width={400}
                  height={500}
                  className="relative rounded-2xl shadow-xl w-full h-auto border-4 border-white"
                />
                <div className="absolute -bottom-4 -right-4 bg-white rounded-xl p-4 shadow-lg border border-gray-100">
                  <p className="text-sm font-semibold text-gray-900">📍 Tampa, FL</p>
                  <p className="text-xs text-gray-600">Originally from NYC 🗽</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-24 px-4 bg-white">
        <div className="max-w-4xl mx-auto">
          <Card className="mb-12 border border-gray-100 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-teal-50 to-cyan-50 border-b border-gray-100">
              <CardTitle className="text-3xl text-teal-600">My Journey</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-lg max-w-none p-8">
              <p className="text-gray-700 leading-relaxed mb-6">
                I'm Alessia Pedrazzoli, and like a lot of people my age, I found myself in a new city—excited, curious,
                and unsure of what to expect. I grew up in New York—the Big Apple—where something's always happening and
                the pace never slows down. When I moved to Tampa just before starting college, I was ready for sunshine,
                palm trees, and a new chapter full of fun and adventure.
              </p>

              <p className="text-gray-700 leading-relaxed mb-6">
                But once I got here, I quickly realized that being 18 to 20 came with unexpected limitations. So much of
                the social scene in Tampa revolves around bars and clubs that are 21 and up. I didn't know where to go
                or what to do without feeling like I either had to stay home or pretend to be older just to be part of
                the fun.
              </p>

              <p className="text-gray-700 leading-relaxed mb-6">
                What struck me most was the pervasive culture that equates fun with drinking. There's this unspoken idea
                that to enjoy yourself—especially on weekends—alcohol has to be involved. I found that mindset limiting
                and, honestly, disheartening. I didn't want to feel like I had to drink just to fit in or have a good
                time.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-12 border border-gray-100 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-cyan-50 to-teal-50 border-b border-gray-100">
              <CardTitle className="text-3xl text-cyan-600">A Different Perspective</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-lg max-w-none p-8">
              <p className="text-gray-700 leading-relaxed mb-6">
                That's part of why I created this site—not just because of what I was missing in Tampa, but also because
                of what I've experienced elsewhere. I'm Swiss, and I've traveled extensively throughout Europe, where
                the mindset around going out is completely different. In many places, young people can go out as early
                as 16, and there isn't the same pressure to "drink to have fun." Social life isn't limited by age or
                alcohol—it's about freedom, connection, and genuinely enjoying the moment.
              </p>

              <p className="text-gray-700 leading-relaxed mb-6">
                That sense of liberty stuck with me, and it made the contrast here in the U.S. even more glaring. So, I
                wanted to challenge that idea and prove that alcohol isn't a requirement for connection, fun, or
                unforgettable memories.
              </p>
            </CardContent>
          </Card>

          <Card className="border border-gray-100 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-teal-50 to-white border-b border-gray-100">
              <CardTitle className="text-3xl text-teal-600">The Mission</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-lg max-w-none p-8">
              <p className="text-gray-700 leading-relaxed mb-6">
                Tampa—and the surrounding areas like St. Pete and Dunedin—actually have a lot to offer for the 18+
                crowd. From 18+ clubs and live music venues to outdoor adventures, late-night food spots, and creative
                hangouts, there are countless ways to enjoy yourself without relying on alcohol or a fake ID.
              </p>

              <p className="text-gray-700 leading-relaxed mb-6">
                This site is about embracing that lifestyle. It's here to show you the experiences, spots, and vibes
                that don't center around drinking but still deliver everything you're looking for—energy, connection,
                adventure, and fun. Whether you're new to the area or just want something different, I hope this
                platform helps you discover the other side of Tampa Bay's social scene.
              </p>

              <div className="bg-gradient-to-r from-teal-500 to-cyan-500 p-6 rounded-xl text-white font-semibold text-lg text-center shadow-lg">
                You don't need to wait until you're 21 to live your life—and you definitely don't need a drink in your
                hand to enjoy it.
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Photo Gallery Section */}
      <section className="py-24 px-4 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">My Tampa Bay Adventures</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="relative group">
              <Image
                src="/placeholder.svg?height=300&width=400"
                alt="Exploring Tampa"
                width={400}
                height={300}
                className="w-full h-64 object-cover rounded-2xl shadow-lg group-hover:shadow-xl transition-shadow border border-gray-100"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-teal-500/50 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="absolute bottom-4 left-4 text-white">
                  <p className="font-semibold">Exploring Tampa</p>
                </div>
              </div>
            </div>
            <div className="relative group">
              <Image
                src="/placeholder.svg?height=300&width=400"
                alt="Beach day adventures"
                width={400}
                height={300}
                className="w-full h-64 object-cover rounded-2xl shadow-lg group-hover:shadow-xl transition-shadow border border-gray-100"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-cyan-500/50 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="absolute bottom-4 left-4 text-white">
                  <p className="font-semibold">Beach Adventures</p>
                </div>
              </div>
            </div>
            <div className="relative group">
              <Image
                src="/placeholder.svg?height=300&width=400"
                alt="Food discoveries"
                width={400}
                height={300}
                className="w-full h-64 object-cover rounded-2xl shadow-lg group-hover:shadow-xl transition-shadow border border-gray-100"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-teal-600/50 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="absolute bottom-4 left-4 text-white">
                  <p className="font-semibold">Food Discoveries</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
