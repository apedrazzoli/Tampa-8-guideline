import Link from "next/link"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MapPin, Utensils, Waves, Music, Gamepad2 } from "lucide-react"

const quickLinks = [
  {
    title: "Tampa Restaurants",
    description: "Discover the best dining spots in Tampa",
    icon: Utensils,
    href: "/restaurants#tampa",
    color: "text-teal-500",
  },
  {
    title: "St. Pete Nightlife",
    description: "Explore St. Petersburg's vibrant night scene",
    icon: Music,
    href: "/nightlife",
    color: "text-purple-500",
  },
  {
    title: "Clearwater Beaches",
    description: "Find your perfect beach day spot",
    icon: Waves,
    href: "/beaches",
    color: "text-cyan-500",
  },
  {
    title: "Gaming & Arcades",
    description: "Level up your fun at Tampa's best arcades",
    icon: Gamepad2,
    href: "/activities#gaming",
    color: "text-orange-500",
  },
]

const featuredSpots = [
  {
    name: "Bulla GastroBar",
    location: "Tampa",
    type: "Restaurant",
    description: "Rooftop Spanish tapas with amazing city views",
  },
  {
    name: "Fort De Soto Park",
    location: "St. Petersburg",
    type: "Beach",
    description: "Multiple beaches, bike trails, and dog-friendly areas",
  },
  {
    name: "Club Prana",
    location: "Ybor City",
    type: "Nightlife",
    description: "Multi-level 18+ club with different music on each floor",
  },
  {
    name: "Elite Water Sports",
    location: "Tampa Bay",
    type: "Activity",
    description: "Jet skiing, parasailing, and water adventures",
  },
]

export default function ExplorePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-teal-50 to-cyan-50 py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            <span className="text-teal-500">Explore</span> Tampa Bay
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Your adventure starts here. Browse by category or discover featured spots that make Tampa Bay the perfect
            place for 18+ fun.
          </p>
        </div>
      </section>

      {/* Quick Navigation */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Where to Start</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {quickLinks.map((link, index) => {
              const IconComponent = link.icon
              return (
                <Link key={index} href={link.href} className="group">
                  <Card className="h-full hover:shadow-lg transition-shadow">
                    <CardHeader className="text-center">
                      <IconComponent
                        className={`w-12 h-12 mx-auto mb-4 ${link.color} group-hover:scale-110 transition-transform`}
                      />
                      <CardTitle className="text-lg group-hover:text-teal-500 transition-colors">
                        {link.title}
                      </CardTitle>
                      <CardDescription>{link.description}</CardDescription>
                    </CardHeader>
                  </Card>
                </Link>
              )
            })}
          </div>
        </div>
      </section>

      {/* Featured Spots */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Featured This Week</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredSpots.map((spot, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-lg">{spot.name}</CardTitle>
                    <span className="text-sm text-teal-500 font-medium">{spot.type}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-500 mb-3">
                    <MapPin className="w-4 h-4 mr-1" />
                    {spot.location}
                  </div>
                  <CardDescription>{spot.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 px-4 bg-gradient-to-r from-teal-500 to-cyan-500">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-4xl font-bold mb-6">Ready for Your Next Adventure?</h2>
          <p className="text-xl mb-8 opacity-90">
            Browse all our categories to discover everything Tampa Bay has to offer
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link href="/restaurants">Restaurants</Link>
            </Button>
            <Button asChild size="lg" variant="secondary">
              <Link href="/beaches">Beaches</Link>
            </Button>
            <Button asChild size="lg" variant="secondary">
              <Link href="/nightlife">Nightlife</Link>
            </Button>
            <Button asChild size="lg" variant="secondary">
              <Link href="/activities">Activities</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
