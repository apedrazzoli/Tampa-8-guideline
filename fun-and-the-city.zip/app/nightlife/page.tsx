import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Music, Mic, MapPin } from "lucide-react"

const nightlifeSpots = {
  ybor: [
    {
      name: "Showbar",
      description: "High-energy club with live performances and dancing",
      type: "Club",
      highlights: ["Live Shows", "Dancing", "18+", "High Energy"],
    },
    {
      name: "Tangra",
      description: "Trendy nightclub with DJ sets and modern vibes",
      type: "Nightclub",
      highlights: ["DJ Sets", "Modern Atmosphere", "18+", "Trendy"],
    },
    {
      name: "Club Prana",
      description: "Multi-level club with different music styles",
      type: "Multi-Level Club",
      highlights: ["Multiple Floors", "Varied Music", "18+", "Large Venue"],
    },
  ],
  soho: [
    {
      name: "HPC",
      description: "Popular spot with great music and social atmosphere",
      type: "Bar/Club",
      highlights: ["Social Scene", "Great Music", "Popular", "Energetic"],
    },
    {
      name: "Pete's Place Karaoke Bar",
      description: "Local favorite karaoke spot full of friendly faces",
      type: "Karaoke Bar",
      highlights: ["Karaoke", "Local Crowd", "Friendly", "Sing-Along Fun"],
    },
  ],
  downtown: [
    {
      name: "Ivy Rose",
      description: "Upscale lounge with sophisticated atmosphere",
      type: "Lounge",
      highlights: ["Upscale", "Sophisticated", "Cocktails", "Elegant"],
    },
    {
      name: "Litt Club",
      description: "High-energy club with top DJs and dancing",
      type: "Club",
      highlights: ["Top DJs", "Dancing", "High Energy", "Popular"],
    },
    {
      name: "Eden",
      description: "Trendy nightspot with modern design and great vibes",
      type: "Nightclub",
      highlights: ["Modern Design", "Great Vibes", "Trendy", "Stylish"],
    },
  ],
}

export default function NightlifePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-white via-teal-50 to-cyan-50 py-24 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=1200')] bg-cover bg-center opacity-10"></div>
        <div className="relative max-w-6xl mx-auto text-center">
          <h1 className="text-6xl font-bold mb-8 text-gray-900">
            <span className="bg-gradient-to-r from-teal-500 to-cyan-500 bg-clip-text text-transparent">Nightlife</span>{" "}
            & Entertainment
          </h1>
          <p className="text-xl max-w-3xl mx-auto text-gray-700">
            Experience Tampa's vibrant 18+ nightlife scene. From high-energy clubs to intimate karaoke bars, discover
            where the night comes alive.
          </p>
        </div>
      </section>

      {/* Ybor City */}
      <section className="py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center mb-16">
            <Music className="w-10 h-10 text-teal-500 mr-4" />
            <h2 className="text-5xl font-bold text-gray-900">Ybor City</h2>
            <Badge className="ml-4 bg-teal-100 text-teal-700">Historic Nightlife District</Badge>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-24">
            {nightlifeSpots.ybor.map((spot, index) => (
              <Card key={index} className="hover:shadow-xl transition-shadow border border-gray-100 bg-white">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-xl">{spot.name}</CardTitle>
                    <Badge variant="secondary" className="bg-teal-100 text-teal-700">
                      {spot.type}
                    </Badge>
                  </div>
                  <CardDescription className="text-base">{spot.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {spot.highlights.map((highlight, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs border-gray-200">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* SoHo */}
          <div className="flex items-center mb-16">
            <Mic className="w-10 h-10 text-cyan-500 mr-4" />
            <h2 className="text-5xl font-bold text-gray-900">SoHo</h2>
            <Badge className="ml-4 bg-cyan-100 text-cyan-700">Social Hub</Badge>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-24">
            {nightlifeSpots.soho.map((spot, index) => (
              <Card key={index} className="hover:shadow-xl transition-shadow border border-gray-100 bg-white">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-xl">{spot.name}</CardTitle>
                    <Badge variant="secondary" className="bg-cyan-100 text-cyan-700">
                      {spot.type}
                    </Badge>
                  </div>
                  <CardDescription className="text-base">{spot.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {spot.highlights.map((highlight, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs border-gray-200">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Downtown */}
          <div className="flex items-center mb-16">
            <MapPin className="w-10 h-10 text-teal-600 mr-4" />
            <h2 className="text-5xl font-bold text-gray-900">Downtown Tampa</h2>
            <Badge className="ml-4 bg-teal-100 text-teal-700">Urban Scene</Badge>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {nightlifeSpots.downtown.map((spot, index) => (
              <Card key={index} className="hover:shadow-xl transition-shadow border border-gray-100 bg-white">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-xl">{spot.name}</CardTitle>
                    <Badge variant="secondary" className="bg-teal-100 text-teal-700">
                      {spot.type}
                    </Badge>
                  </div>
                  <CardDescription className="text-base">{spot.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {spot.highlights.map((highlight, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs border-gray-200">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Nightlife Tips */}
      <section className="py-24 px-4 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-5xl font-bold text-center text-gray-900 mb-20">Night Out Tips</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border border-gray-100 shadow-lg bg-white">
              <CardHeader>
                <CardTitle className="text-xl text-teal-600">18+ Venues</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  All listed venues welcome 18+ guests. Always bring valid ID and check specific event requirements.
                </p>
              </CardContent>
            </Card>

            <Card className="border border-gray-100 shadow-lg bg-white">
              <CardHeader>
                <CardTitle className="text-xl text-cyan-600">Best Nights</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Thursday-Saturday are peak nights. Check social media for special events and themed nights.
                </p>
              </CardContent>
            </Card>

            <Card className="border border-gray-100 shadow-lg bg-white">
              <CardHeader>
                <CardTitle className="text-xl text-teal-600">Getting Around</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Use rideshare apps, designated drivers, or public transit. Many venues are walkable in each district.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
