import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Waves, Target, Gamepad2, Zap, ExternalLink } from "lucide-react"

const activities = {
  outdoor: [
    {
      name: "Elite Water Sports",
      description: "Jet skiing, parasailing, and water adventures",
      type: "Water Sports",
      highlights: ["Jet Skiing", "Parasailing", "Boat Rentals", "Gulf Access"],
      website: "https://elitewatersports.com",
    },
    {
      name: "Empower Adventures Tampa Bay",
      description: "Zip lining and outdoor adventure courses",
      type: "Adventure Park",
      highlights: ["Zip Lines", "Obstacle Courses", "Team Building", "Nature"],
      website: "https://www.visitstpeteclearwater.com/profile/empower-adventures-tampa-bay/138835",
    },
  ],
  sports: [
    {
      name: "PopStroke Tampa",
      description: "Premium mini golf experience with food and drinks",
      type: "Mini Golf",
      highlights: ["Premium Course", "Food & Drinks", "Social Atmosphere", "Modern Design"],
      website: "https://popstroke.com/venues/tampa-wesley-chapel/",
    },
    {
      name: "TB Pickleball Oldsmar",
      description: "Indoor pickleball courts and leagues",
      type: "Pickleball",
      highlights: ["Indoor Courts", "Leagues", "Equipment Rental", "All Levels"],
      website: "https://tbpickleball.com/oldsmar",
    },
    {
      name: "Pickleheads at Rowlett Park",
      description: "Outdoor pickleball courts in Tampa",
      type: "Outdoor Pickleball",
      highlights: ["Outdoor Courts", "Free Play", "Community", "Tampa Location"],
      website: "https://www.pickleheads.com/courts/us/florida/tampa/rowlett-park",
    },
  ],
  gaming: [
    {
      name: "1UP Arcade Bar",
      description: "Classic arcade games and modern gaming",
      type: "Arcade",
      highlights: ["Classic Games", "Modern Gaming", "Social Atmosphere", "Tournaments"],
      website: "https://playat1up.com",
    },
    {
      name: "Reboot Amusements",
      description: "Retro arcade with pinball and classic games",
      type: "Retro Arcade",
      highlights: ["Pinball", "Retro Games", "Nostalgic Vibes", "All Ages"],
      website: "https://www.rebootamusements.com",
    },
    {
      name: "GameTime Players",
      description: "Gaming lounge with console and PC gaming",
      type: "Gaming Lounge",
      highlights: ["Console Gaming", "PC Gaming", "Tournaments", "Social Gaming"],
      website: "https://www.gametimeplayers.com/home-tampa/",
    },
    {
      name: "Elev8 Fun",
      description: "Multi-level entertainment with arcade and activities",
      type: "Entertainment Center",
      highlights: ["Multi-Level", "Arcade", "Activities", "Group Fun"],
      website: "https://www.elev8fun.com/about",
    },
    {
      name: "Lowry Arcade",
      description: "Local arcade with classic and modern games",
      type: "Local Arcade",
      highlights: ["Classic Games", "Modern Games", "Local Favorite", "Affordable"],
      website: "https://lowryparcade.com/",
    },
  ],
  action: [
    {
      name: "LaserOps",
      description: "High-tech laser tag arena with multiple game modes",
      type: "Laser Tag",
      highlights: ["High-Tech Arena", "Multiple Game Modes", "Team Building", "Competitive"],
      website: "https://www.laserops.com/",
    },
  ],
}

const hotSpots = [
  {
    name: "Armature Works",
    description: "Food hall and event space with river views",
    type: "Food Hall & Events",
  },
  {
    name: "Water Street Tampa",
    description: "Modern district with dining, entertainment, and bowling",
    type: "Entertainment District",
  },
  {
    name: "Downtown St. Petersburg",
    description: "Arts district with galleries, restaurants, and nightlife",
    type: "Arts & Culture",
  },
  {
    name: "Clearwater Beach",
    description: "Beach town with shops, restaurants, and activities",
    type: "Beach Town",
  },
]

export default function ActivitiesPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-50 to-red-50 py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            <span className="text-orange-500">Activities</span> & Adventures
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From water sports and laser tag to arcade gaming and mini golf, discover endless ways to have fun in Tampa
            Bay.
          </p>
        </div>
      </section>

      {/* Outdoor Activities */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center mb-12">
            <Waves className="w-8 h-8 text-blue-500 mr-3" />
            <h2 className="text-4xl font-bold text-gray-900">Outdoor Adventures</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-8 mb-20">
            {activities.outdoor.map((activity, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-xl">{activity.name}</CardTitle>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                      {activity.type}
                    </Badge>
                  </div>
                  <CardDescription className="text-base mb-4">{activity.description}</CardDescription>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {activity.highlights.map((highlight, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <Button asChild variant="outline" size="sm">
                    <a href={activity.website} target="_blank" rel="noopener noreferrer">
                      Visit Website <ExternalLink className="w-4 h-4 ml-2" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Sports & Recreation */}
          <div className="flex items-center mb-12">
            <Target className="w-8 h-8 text-green-500 mr-3" />
            <h2 className="text-4xl font-bold text-gray-900">Sports & Recreation</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
            {activities.sports.map((activity, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-xl">{activity.name}</CardTitle>
                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                      {activity.type}
                    </Badge>
                  </div>
                  <CardDescription className="text-base mb-4">{activity.description}</CardDescription>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {activity.highlights.map((highlight, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <Button asChild variant="outline" size="sm">
                    <a href={activity.website} target="_blank" rel="noopener noreferrer">
                      Visit Website <ExternalLink className="w-4 h-4 ml-2" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Gaming & Arcades */}
          <div className="flex items-center mb-12">
            <Gamepad2 className="w-8 h-8 text-purple-500 mr-3" />
            <h2 className="text-4xl font-bold text-gray-900">Gaming & Arcades</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
            {activities.gaming.map((activity, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-xl">{activity.name}</CardTitle>
                    <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                      {activity.type}
                    </Badge>
                  </div>
                  <CardDescription className="text-base mb-4">{activity.description}</CardDescription>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {activity.highlights.map((highlight, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <Button asChild variant="outline" size="sm">
                    <a href={activity.website} target="_blank" rel="noopener noreferrer">
                      Visit Website <ExternalLink className="w-4 h-4 ml-2" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Action & Adventure */}
          <div className="flex items-center mb-12">
            <Zap className="w-8 h-8 text-red-500 mr-3" />
            <h2 className="text-4xl font-bold text-gray-900">Action & Adventure</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {activities.action.map((activity, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-xl">{activity.name}</CardTitle>
                    <Badge variant="secondary" className="bg-red-100 text-red-700">
                      {activity.type}
                    </Badge>
                  </div>
                  <CardDescription className="text-base mb-4">{activity.description}</CardDescription>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {activity.highlights.map((highlight, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <Button asChild variant="outline" size="sm">
                    <a href={activity.website} target="_blank" rel="noopener noreferrer">
                      Visit Website <ExternalLink className="w-4 h-4 ml-2" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Hot Spots */}
      <section className="py-20 px-4 bg-gradient-to-r from-orange-50 to-red-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Places to Be</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {hotSpots.map((spot, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg">{spot.name}</CardTitle>
                  <Badge variant="secondary" className="w-fit bg-orange-100 text-orange-700">
                    {spot.type}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm">{spot.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Activity Tips */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Activity Tips</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-blue-600">Book Ahead</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Popular activities like water sports and adventure courses fill up quickly, especially on weekends.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-green-600">Group Discounts</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Many venues offer group rates for parties of 6+. Perfect for birthday celebrations or friend outings.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-purple-600">Mix & Match</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Combine activities for the perfect day out - mini golf followed by arcade games, or water sports then
                  beach dining.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
