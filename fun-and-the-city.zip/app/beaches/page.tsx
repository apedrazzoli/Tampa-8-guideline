import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Waves, Sun, Camera } from "lucide-react"
import Image from "next/image"

const beaches = [
  {
    name: "Coconut Charlie's",
    location: "Clearwater",
    description: "Beach bar with music, volleyball, and mocktails",
    activities: ["Volleyball", "Live Music", "Mocktails", "Beach Games"],
    vibe: "Party Beach",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    name: "Caddy's on the Beach",
    location: "Treasure Island",
    description: "Food, music, and sunsets on the sand",
    activities: ["Live Music", "Sunset Views", "Beach Dining", "Dancing"],
    vibe: "Sunset Spot",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    name: "Pass-a-Grille Beach",
    location: "St. Pete Beach",
    description: "Laid-back beach with shops and cafés",
    activities: ["Shopping", "Cafés", "Walking", "Relaxing"],
    vibe: "Laid-back",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    name: "Fort De Soto Park",
    location: "St. Petersburg",
    description: "Multiple beaches, bike trails, dog beach, and history",
    activities: ["Biking", "Dog Beach", "History", "Multiple Beaches"],
    vibe: "Adventure",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    name: "Indian Rocks Beach",
    location: "Indian Rocks",
    description: "Quiet, wide beach for games and relaxing",
    activities: ["Beach Games", "Swimming", "Sunbathing", "Walking"],
    vibe: "Peaceful",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    name: "Apollo Beach",
    location: "Apollo Beach",
    description: "Peaceful with fishing and wildlife viewing",
    activities: ["Fishing", "Wildlife Watching", "Photography", "Nature"],
    vibe: "Nature",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    name: "Davis Islands Beach",
    location: "Tampa",
    description: "Skyline views and a local, chill scene",
    activities: ["City Views", "Local Hangout", "Swimming", "Picnics"],
    vibe: "Local Favorite",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    name: "Treasure Island",
    location: "Treasure Island",
    description: "Volleyball courts, water sports, and beach bars",
    activities: ["Volleyball", "Water Sports", "Beach Bars", "Rentals"],
    vibe: "Active",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    name: "Honeymoon Island",
    location: "Dunedin",
    description: "Shelling, trails, and natural beauty",
    activities: ["Shelling", "Nature Trails", "Wildlife", "Photography"],
    vibe: "Natural",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    name: "St. Pete Beach",
    location: "St. Pete Beach",
    description: "Classic busy beach with parasailing and shops",
    activities: ["Parasailing", "Shopping", "Water Sports", "Dining"],
    vibe: "Classic Beach",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    name: "White Sand Beach",
    location: "Clearwater",
    description: "Soft sand, perfect for games and group outings",
    activities: ["Beach Games", "Group Activities", "Swimming", "Sunbathing"],
    vibe: "Group Fun",
    image: "/placeholder.svg?height=300&width=400",
  },
]

export default function BeachesPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-white via-cyan-50 to-teal-50 py-24 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=1200')] bg-cover bg-center opacity-10"></div>
        <div className="relative max-w-6xl mx-auto text-center">
          <h1 className="text-6xl font-bold mb-8 text-gray-900">
            <span className="bg-gradient-to-r from-cyan-500 to-teal-500 bg-clip-text text-transparent">Beaches</span> &
            Coastal Fun
          </h1>
          <p className="text-xl max-w-3xl mx-auto text-gray-700">
            From party beaches with live music to peaceful nature spots, discover Tampa Bay's most beautiful coastlines
            and the endless activities they offer.
          </p>
        </div>
      </section>

      {/* Beach Grid */}
      <section className="py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {beaches.map((beach, index) => (
              <Card
                key={index}
                className="group hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-100 bg-white"
              >
                <div className="relative">
                  <Image
                    src={beach.image || "/placeholder.svg"}
                    alt={beach.name}
                    width={400}
                    height={250}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
                  <div className="absolute top-4 right-4">
                    <Badge
                      variant="secondary"
                      className={`
                        ${beach.vibe.includes("Party") ? "bg-teal-500/90 text-white" : ""}
                        ${beach.vibe.includes("Sunset") ? "bg-cyan-500/90 text-white" : ""}
                        ${beach.vibe.includes("Nature") || beach.vibe.includes("Natural") ? "bg-teal-600/90 text-white" : ""}
                        ${beach.vibe.includes("Active") ? "bg-cyan-600/90 text-white" : ""}
                        ${beach.vibe.includes("Peaceful") || beach.vibe.includes("Laid-back") ? "bg-teal-400/90 text-white" : ""}
                        ${!beach.vibe.includes("Party") && !beach.vibe.includes("Sunset") && !beach.vibe.includes("Nature") && !beach.vibe.includes("Natural") && !beach.vibe.includes("Active") && !beach.vibe.includes("Peaceful") && !beach.vibe.includes("Laid-back") ? "bg-cyan-500/90 text-white" : ""}
                      `}
                    >
                      {beach.vibe}
                    </Badge>
                  </div>
                  <div className="absolute bottom-4 left-4 text-white">
                    <div className="flex items-center text-sm">
                      <Waves className="w-4 h-4 mr-1" />
                      {beach.location}
                    </div>
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-xl">{beach.name}</CardTitle>
                  <CardDescription className="text-base">{beach.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {beach.activities.map((activity, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs border-gray-200">
                        {activity}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Beach Tips Section */}
      <section className="py-24 px-4 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-5xl font-bold text-center text-gray-900 mb-20">Beach Day Tips</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border border-gray-100 shadow-lg bg-white">
              <CardHeader className="text-center">
                <Sun className="w-16 h-16 text-teal-500 mx-auto mb-4" />
                <CardTitle className="text-2xl">Best Times to Visit</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">
                  Early morning (7-10am) for peaceful vibes, late afternoon (4-7pm) for sunset views and social scenes.
                </p>
              </CardContent>
            </Card>

            <Card className="border border-gray-100 shadow-lg bg-white">
              <CardHeader className="text-center">
                <Waves className="w-16 h-16 text-cyan-500 mx-auto mb-4" />
                <CardTitle className="text-2xl">What to Bring</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">
                  Sunscreen, water, snacks, beach games, portable speaker, and a cooler for the perfect beach day.
                </p>
              </CardContent>
            </Card>

            <Card className="border border-gray-100 shadow-lg bg-white">
              <CardHeader className="text-center">
                <Camera className="w-16 h-16 text-teal-600 mx-auto mb-4" />
                <CardTitle className="text-2xl">Photo Spots</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">
                  Sunset at Caddy's, skyline views from Davis Islands, and natural beauty at Honeymoon Island.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
