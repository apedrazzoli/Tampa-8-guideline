import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Star } from "lucide-react"
import Image from "next/image"

const restaurants = {
  tampa: [
    // Breakfast Spots
    {
      name: "Oxford Exchange",
      description: "Upscale café with artisanal coffee and gourmet breakfast",
      vibe: "Upscale Café",
      highlights: ["Artisanal Coffee", "Gourmet Breakfast", "Instagram-Worthy", "Study Spot"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Buddy Brew Coffee",
      description: "Local coffee roaster with amazing breakfast sandwiches",
      vibe: "Local Coffee",
      highlights: ["Local Roaster", "Breakfast Sandwiches", "Multiple Locations", "Student Friendly"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "First Watch",
      description: "Fresh breakfast and brunch with healthy options",
      vibe: "Fresh & Healthy",
      highlights: ["Healthy Options", "Fresh Ingredients", "Brunch Menu", "Casual Dining"],
      image: "/placeholder.svg?height=300&width=400",
    },
    // Existing restaurants...
    {
      name: "Olivia",
      description: "Modern Italian with an open kitchen",
      vibe: "Upscale Casual",
      highlights: ["Open Kitchen", "Modern Italian", "Great Atmosphere"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Besos",
      description: "Upscale Mexican, tableside guac, cocktails",
      vibe: "Upscale",
      highlights: ["Tableside Guac", "Craft Cocktails", "Mexican Cuisine"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Timpano",
      description: "Bold Italian-American with a lively scene",
      vibe: "Lively",
      highlights: ["Italian-American", "Energetic Vibe", "Great for Groups"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Bartaco",
      description: "Coastal vibes, handheld bites",
      vibe: "Casual",
      highlights: ["Coastal Theme", "Tacos", "Relaxed Atmosphere"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Prime Water",
      description: "Seafood with great views",
      vibe: "Upscale",
      highlights: ["Waterfront Views", "Fresh Seafood", "Scenic Dining"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Salt Shack on the Bay",
      description: "Tropical seafood escape",
      vibe: "Tropical",
      highlights: ["Bay Views", "Tropical Vibes", "Seafood Specialties"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Jay Luigi",
      description: "Classy casual Italian and bar",
      vibe: "Classy Casual",
      highlights: ["Italian Cuisine", "Bar Scene", "Sophisticated"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Latin Grill",
      description: "Latin food + dance floor + LED vibes",
      vibe: "Party",
      highlights: ["Dance Floor", "LED Lighting", "Latin Music"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Bulla GastroBar",
      description: "Rooftop lounge, Spanish tapas",
      vibe: "Rooftop",
      highlights: ["Rooftop Views", "Spanish Tapas", "Lounge Atmosphere"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Green Lemon",
      description: "SoHo's fun Mexican street food spot",
      vibe: "Fun & Casual",
      highlights: ["Street Food", "SoHo Location", "Vibrant Atmosphere"],
      image: "/placeholder.svg?height=300&width=400",
    },
  ],
  stPete: [
    // Breakfast Spots
    {
      name: "The Mill",
      description: "Trendy breakfast spot with creative dishes and great coffee",
      vibe: "Trendy Breakfast",
      highlights: ["Creative Dishes", "Great Coffee", "Instagram-Worthy", "Local Favorite"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Ruby's Elixir",
      description: "Health-focused café with smoothie bowls and avocado toast",
      vibe: "Health Café",
      highlights: ["Smoothie Bowls", "Avocado Toast", "Health-Focused", "Fresh Ingredients"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Banyan Café",
      description: "Cozy breakfast spot with homemade pastries and specialty coffee",
      vibe: "Cozy Café",
      highlights: ["Homemade Pastries", "Specialty Coffee", "Cozy Atmosphere", "Local Gem"],
      image: "/placeholder.svg?height=300&width=400",
    },
    // Existing restaurants...
    {
      name: "Cassis",
      description: "Brasserie with American comfort food and a party vibe",
      vibe: "Party Brasserie",
      highlights: ["Comfort Food", "Party Atmosphere", "American Cuisine"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Doc Ford Rum Bar & Grille",
      description: "Caribbean-Latin waterfront with live music",
      vibe: "Waterfront",
      highlights: ["Live Music", "Caribbean-Latin", "Waterfront Dining"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Ceviche",
      description: "Flamenco, tapas, sangria, and festive energy",
      vibe: "Festive",
      highlights: ["Flamenco Shows", "Spanish Tapas", "Festive Energy"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Bacchus",
      description: "European flair, charcuterie, and live music",
      vibe: "European",
      highlights: ["Charcuterie", "Live Music", "European Atmosphere"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Rain Fusion",
      description: "Neon-lit Asian fusion with mocktails and music",
      vibe: "Neon Vibes",
      highlights: ["Asian Fusion", "Mocktails", "Neon Lighting"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Birchwood",
      description: "Rooftop lounge, sunset views, and small plates",
      vibe: "Rooftop",
      highlights: ["Sunset Views", "Small Plates", "Rooftop Lounge"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Trys",
      description: "Open kitchen, modern decor, and shareable dishes",
      vibe: "Modern",
      highlights: ["Open Kitchen", "Shareable Dishes", "Modern Design"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Social Roost",
      description: "Global comfort food and colorful mocktails",
      vibe: "Social",
      highlights: ["Global Cuisine", "Colorful Mocktails", "Social Atmosphere"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Haiku",
      description: "Sushi, ramen, garden-style decor, and a buzzing vibe",
      vibe: "Garden Style",
      highlights: ["Sushi & Ramen", "Garden Decor", "Buzzing Atmosphere"],
      image: "/placeholder.svg?height=300&width=400",
    },
  ],
  clearwater: [
    // Breakfast Spots
    {
      name: "Lenny's Restaurant",
      description: "Classic American breakfast diner with huge portions",
      vibe: "Classic Diner",
      highlights: ["Huge Portions", "Classic American", "Affordable", "Local Institution"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Another Broken Egg Café",
      description: "Upscale breakfast and brunch with creative twists",
      vibe: "Upscale Brunch",
      highlights: ["Creative Twists", "Upscale Brunch", "Specialty Coffee", "Weekend Favorite"],
      image: "/placeholder.svg?height=300&width=400",
    },
    // Existing restaurants...
    {
      name: "Island Way Grill",
      description: "Seafood and sushi with waterfront views",
      vibe: "Waterfront",
      highlights: ["Waterfront Views", "Sushi", "Fresh Seafood"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "The Sandbar at Opal Sands",
      description: "Beach eats with music and sunset views",
      vibe: "Beach",
      highlights: ["Beach Location", "Live Music", "Sunset Views"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Marina Cantina",
      description: "Rooftop Mexican fusion and fresh-caught seafood",
      vibe: "Rooftop",
      highlights: ["Mexican Fusion", "Fresh Seafood", "Rooftop Dining"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Bavaro's",
      description: "Neapolitan pizza in a social, upbeat setting",
      vibe: "Social",
      highlights: ["Neapolitan Pizza", "Upbeat Atmosphere", "Social Setting"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Frenchy's Rockaway Grill",
      description: "Casual beach staple with seafood and music",
      vibe: "Beach Casual",
      highlights: ["Beach Staple", "Live Music", "Casual Dining"],
      image: "/placeholder.svg?height=300&width=400",
    },
  ],
  dunedin: [
    // Breakfast Spots
    {
      name: "Café Alfresco",
      description: "European-style café with fresh pastries and strong coffee",
      vibe: "European Café",
      highlights: ["Fresh Pastries", "Strong Coffee", "European Style", "Outdoor Seating"],
      image: "/placeholder.svg?height=300&width=400",
    },
    // Existing restaurants...
    {
      name: "Casa Tina",
      description: "Festive Mexican restaurant with a vibrant feel",
      vibe: "Festive",
      highlights: ["Mexican Cuisine", "Vibrant Atmosphere", "Festive Decor"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "The Living Room",
      description: "Cozy comfort food in a homey setting",
      vibe: "Cozy",
      highlights: ["Comfort Food", "Homey Setting", "Cozy Atmosphere"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Bon Appetit",
      description: "Rustic French-inspired bistro on the water",
      vibe: "Rustic French",
      highlights: ["French Cuisine", "Waterfront", "Rustic Charm"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "The Honu",
      description: "Hawaiian-themed, family-friendly island vibes",
      vibe: "Hawaiian",
      highlights: ["Hawaiian Theme", "Island Vibes", "Family-Friendly"],
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      name: "Country Boy",
      description: "Hearty American-Greek comfort food",
      vibe: "Comfort",
      highlights: ["American-Greek", "Hearty Portions", "Comfort Food"],
      image: "/placeholder.svg?height=300&width=400",
    },
  ],
}

export default function RestaurantsPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-slate-900 via-orange-900 to-slate-900 py-24 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=1200')] bg-cover bg-center opacity-30"></div>
        <div className="relative max-w-6xl mx-auto text-center text-white">
          <h1 className="text-6xl font-bold mb-8">
            <span className="bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text text-transparent">
              Restaurants
            </span>{" "}
            & Dining
          </h1>
          <p className="text-xl max-w-3xl mx-auto text-gray-200">
            From upscale dining to casual hangouts, discover the best eats across Tampa Bay. Every spot welcomes 18+ and
            offers unforgettable experiences.
          </p>
        </div>
      </section>

      {/* Tampa Restaurants */}
      <section className="py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center mb-16">
            <MapPin className="w-10 h-10 text-teal-500 mr-4" />
            <h2 className="text-5xl font-bold text-gray-900">Tampa</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-24">
            {restaurants.tampa.map((restaurant, index) => (
              <Card key={index} className="group hover:shadow-2xl transition-all duration-300 overflow-hidden border-0">
                <div className="relative">
                  <Image
                    src={restaurant.image || "/placeholder.svg"}
                    alt={restaurant.name}
                    width={400}
                    height={250}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                  <div className="absolute top-4 right-4">
                    <Badge variant="secondary" className="bg-teal-500/90 text-white">
                      {restaurant.vibe}
                    </Badge>
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-xl">{restaurant.name}</CardTitle>
                  <CardDescription className="text-base">{restaurant.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {restaurant.highlights.map((highlight, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* St. Petersburg Restaurants */}
          <div className="flex items-center mb-16">
            <Star className="w-10 h-10 text-cyan-500 mr-4" />
            <h2 className="text-5xl font-bold text-gray-900">St. Petersburg</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-24">
            {restaurants.stPete.map((restaurant, index) => (
              <Card key={index} className="group hover:shadow-2xl transition-all duration-300 overflow-hidden border-0">
                <div className="relative">
                  <Image
                    src={restaurant.image || "/placeholder.svg"}
                    alt={restaurant.name}
                    width={400}
                    height={250}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                  <div className="absolute top-4 right-4">
                    <Badge variant="secondary" className="bg-cyan-500/90 text-white">
                      {restaurant.vibe}
                    </Badge>
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-xl">{restaurant.name}</CardTitle>
                  <CardDescription className="text-base">{restaurant.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {restaurant.highlights.map((highlight, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Clearwater Restaurants */}
          <div className="flex items-center mb-16">
            <MapPin className="w-10 h-10 text-teal-400 mr-4" />
            <h2 className="text-5xl font-bold text-gray-900">Clearwater</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-24">
            {restaurants.clearwater.map((restaurant, index) => (
              <Card key={index} className="group hover:shadow-2xl transition-all duration-300 overflow-hidden border-0">
                <div className="relative">
                  <Image
                    src={restaurant.image || "/placeholder.svg"}
                    alt={restaurant.name}
                    width={400}
                    height={250}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                  <div className="absolute top-4 right-4">
                    <Badge variant="secondary" className="bg-teal-400/90 text-white">
                      {restaurant.vibe}
                    </Badge>
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-xl">{restaurant.name}</CardTitle>
                  <CardDescription className="text-base">{restaurant.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {restaurant.highlights.map((highlight, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Dunedin Restaurants */}
          <div className="flex items-center mb-16">
            <Star className="w-10 h-10 text-cyan-400 mr-4" />
            <h2 className="text-5xl font-bold text-gray-900">Dunedin</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {restaurants.dunedin.map((restaurant, index) => (
              <Card key={index} className="group hover:shadow-2xl transition-all duration-300 overflow-hidden border-0">
                <div className="relative">
                  <Image
                    src={restaurant.image || "/placeholder.svg"}
                    alt={restaurant.name}
                    width={400}
                    height={250}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                  <div className="absolute top-4 right-4">
                    <Badge variant="secondary" className="bg-cyan-400/90 text-white">
                      {restaurant.vibe}
                    </Badge>
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-xl">{restaurant.name}</CardTitle>
                  <CardDescription className="text-base">{restaurant.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {restaurant.highlights.map((highlight, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
